# PERI Chatbot

This is a Flask-based chatbot using Groq API, Sentence Transformers, and other tools.

## 🚀 Deploy to Railway (Free Hosting)

1. Push this code to a GitHub repo.
2. Go to [https://railway.app](https://railway.app)
3. Click **New Project** → **Deploy from GitHub**
4. Set environment variables:
   - `GROQ_API_KEY`
   - `WEATHER_API_KEY`
5. Build Command:
   ```
   pip install -r requirements.txt
   ```
6. Start Command:
   ```
   gunicorn app:app
   ```
7. App will deploy and be live!

## ⚠ Important
- Make sure `index.html` is inside the `templates/` folder.
- Update `index.html`'s fetch URL to use `/chat` relative path.

Enjoy your chatbot! 🤖